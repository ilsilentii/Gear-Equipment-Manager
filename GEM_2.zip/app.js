var express = require("express");
var app = express();
var path = require('path');
var PythonShell = require('python-shell');
//const extract = require('destiny-manifest-extractor');
//let plumbing = require('destiny-manifest-extractor/plumbing')('/home/me/lighthouse/GEM/manifest-content/');
//let fileTree = require('destiny-manifest-extractor/file-tree');
//let tree = fileTree('/home/me/lighthouse/GEM/manifest-content/');

// bind the app to listen for connections on a specified port
var port = process.env.PORT || 3000;
app.listen(port);

app.set("view engine", "ejs");

// Uses scripts folder
app.use("/scripts", express.static(__dirname + "/scripts"));

/*PythonShell.run("pydest/examples/activity_manifest.py", function(err) {
  if (err) throw err;
  console.log('finished');
});*/
//app.use("/pydest/examples", express.static(__dirname + "/pydest/examples"));


// Set up a URL route
app.get("/", function(req, res) {
  res.render("index");
});

console.log("Listening on port " + port);


/*// Render some console log output FILETREE
extract({
    langs: ['en'],
    apiKey: '679daa7ce2064a26a887ae53bae16a61',
    processor: tree.processor
  })
  .then(() => tree.waitDone())
  .then(() => console.log('done!' + tree));
*/

/*extract({
    langs: ['en'],
    apiKey: '679daa7ce2064a26a887ae53bae16a61',
    processor: plumbing.processor
  })
  .then(() => plumbing.write())
  .then(() => console.log('done'));*/