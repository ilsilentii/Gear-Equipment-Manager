import pydest
import asyncio

import cgi, cgitb
cgitb.enable()

# ## Print some data
# data = cgi.FieldStorage()

# print "Content-Type: text/html"
# print some data


async def main():
    destiny = pydest.Pydest('679daa7ce2064a26a887ae53bae16a61')

    hash_dict = {'DestinyActivityDefinition': 'activityHash',
              'DestinyActivityTypeDefinition': 'activityTypeHash',
              'DestinyClassDefinition': 'classHash',
              'DestinyGenderDefinition': 'genderHash',
              'DestinyRaceDefinition': 'raceHash',
              'DestinyInventoryBucketDefinition': 'bucketHash',
              'DestinyInventoryItemDefinition': 'itemHash',
              'DestinyProgressionDefinition': 'progressionHash',
              'DestinyTalentGridDefinition': 'gridHash',
              'DestinyUnlockFlagDefinition': 'flagHash',
              'DestinyHistoricalStatsDefinition': 'statId',
              'DestinyDirectorBookDefinition': 'bookHash',
              'DestinyStatDefinition': 'statHash',
              'DestinySandboxPerkDefinition': 'perkHash',
              'DestinyDestinationDefinition': 'destinationHash',
              'DestinyPlaceDefinition': 'placeHash',
              'DestinyActivityBundleDefinition': 'bundleHash',
              'DestinyStatGroupDefinition': 'statGroupHash',
              'DestinySpecialEventDefinition': 'eventHash',
              'DestinyFactionDefinition': 'factionHash',
              'DestinyVendorCategoryDefinition': 'categoryHash',
              'DestinyEnemyRaceDefinition': 'raceHash',
              'DestinyScriptedSkullDefinition': 'skullHash',
              'DestinyGrimoireCardDefinition': 'cardId'}

    # Decodes user inventory, 9 equipped items
    activity1 = await destiny.decode_hash(2159363321, 'DestinyInventoryItemDefinition')
    await destiny.update_manifest()
    activity2 = await destiny.decode_hash(1644162710, 'DestinyInventoryItemDefinition')
    # activity3 = await destiny.decode_hash(2159363321, 'DestinyInventoryItemDefinition')
    # activity4 = await destiny.decode_hash(1644162710, 'DestinyInventoryItemDefinition')
    # activity5 = await destiny.decode_hash(2159363321, 'DestinyInventoryItemDefinition')
    # activity6 = await destiny.decode_hash(1644162710, 'DestinyInventoryItemDefinition')
    # activity7 = await destiny.decode_hash(2159363321, 'DestinyInventoryItemDefinition')
    # activity8 = await destiny.decode_hash(1644162710, 'DestinyInventoryItemDefinition')
    # activity9 = await destiny.decode_hash(1644162710, 'DestinyInventoryItemDefinition')

    # #Decodes user race, class and gender
    # activity10 = await destiny.decode_hash(raceHash, 'DestinyRaceDefinition')
    # activity11 = await destiny.decode_hash(classHash, 'DestinyClassDefinition')
    # activity12 = await destiny.decode_hash(genderHash, 'DestinyGenderDefinition')

    # Prints for testing
    print("Activity Name: {}".format(activity1['displayProperties']['name']))
    print("Description: {}".format(activity1['displayProperties']['description']))
    print("")
    print("Activity Name: {}".format(activity2['displayProperties']['name']))
    print("Description: {}".format(activity2['displayProperties']['description']))
    print("")
    # print("Activity Name: {}".format(activity3['displayProperties']['name']))
    # print("Description: {}".format(activity3['displayProperties']['description']))
    # print("")
    # print("Activity Name: {}".format(activity4['displayProperties']['name']))
    # print("Description: {}".format(activity4['displayProperties']['description']))
    # print("")
    # print("Activity Name: {}".format(activity5['displayProperties']['name']))
    # print("Description: {}".format(activity5['displayProperties']['description']))
    # print("")
    # print("Activity Name: {}".format(activity6['displayProperties']['name']))
    # print("Description: {}".format(activity6['displayProperties']['description']))
    # print("")
    # print("Activity Name: {}".format(activity7['displayProperties']['name']))
    # print("Description: {}".format(activity7['displayProperties']['description']))
    # print("")
    # print("Activity Name: {}".format(activity8['displayProperties']['name']))
    # print("Description: {}".format(activity8['displayProperties']['description']))
    # print("")
    # print("Activity Name: {}".format(activity9['displayProperties']['name']))
    # print("Description: {}".format(activity9['displayProperties']['description']))
    # print("")
    # print("Activity Name: {}".format(activity10['displayProperties']['name']))
    # print("Description: {}".format(activity10['displayProperties']['description']))
    # print("")
    # print("Activity Name: {}".format(activity11['displayProperties']['name']))
    # print("Description: {}".format(activity11['displayProperties']['description']))
    # print("")
    # print("Activity Name: {}".format(activity12['displayProperties']['name']))
    # print("Description: {}".format(activity12['displayProperties']['description']))

    destiny.close()

loop = asyncio.get_event_loop()
loop.run_until_complete(main())
loop.close()
