var express = require("express");
var app = express();
var path = require('path');
const extract = require('destiny-manifest-extractor');
let fileTree = require('destiny-manifest-extractor/file-tree');
let tree = fileTree('/home/me/lighthouse/GEM/manifest-content.zip');

// bind the app to listen for connections on a specified port
var port = process.env.PORT || 3000;
app.listen(port);

app.set("view engine", "ejs");

// Uses scripts folder
app.use("/scripts", express.static(__dirname + "/scripts"));


// Set up a URL route
app.get("/", function(req, res) {
  res.render("index");
});

// Render some console log output
console.log("Listening on port " + port);

extract({
    langs: ['en'],
    apiKey: '679daa7ce2064a26a887ae53bae16a61',
    processor: tree.processor
  })
  .then(() => tree.waitDone())
  .then(() => console.log('done!' + tree));